package p;

import java.util.Scanner;

public class RideBooking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		String anotherBooking;
		do {
		
		System.out.println("***** SELECT YOUR RIDE *****");
		System.out.println("1.BIKE");
		System.out.println("2.AUTO");
		System.out.println("3.CAR");
		System.out.println("ENTER YOUR CHOICE:");
		int choice=sc.nextInt();
		sc.nextLine();
		
		switch(choice) {
		case 1:
			bike b =new bike();
			b.bikeDisplay();
			break;
		case 2:
			Auto a =new Auto();
			a.AutoDisplay();
			break;
		case 3:
			System.out.println("\n 3. SELECT CAR TYPE:");
			System.out.println("1.MINI");
			System.out.println("2.SEDAN");
			System.out.println("3.LUXURY");
			System.out.println("SELECT YOUR CHOICE:");
			int cartype =sc.nextInt();
			sc.nextLine();
			
			switch(cartype) {
			case 1:
				Mini m =new Mini();
				m.MiniDisplay();
				break;
			case 2:
				sedan s=new sedan();
				s.Sedandisplay();
				break;
			case 3:
				Luxury l=new Luxury();
				l.Luxurydisplay();
				break;
				
			default:
				System.out.println("Invalid Car Type!");
			}
			break;
			
			default:
				System.out.println("Invalid Vehicle choice!");
			}
		System.out.println("\n DO YOU WANT TO BOOK ANOTHER RIDE?(yes/no):");
		anotherBooking=sc.nextLine();
		}
		while(anotherBooking.equals("yes"));
		System.out.println("THANK YOU FOR USING OUR CAB BOOKING SYSYEM!!");
		sc.close();
		}
	}

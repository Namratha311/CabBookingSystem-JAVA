package p;

public class bike extends cab {
	 
	void bikeDisplay() {
		DriverName="kumar";
		Driverphno="9807698076";
		Numberplate="KA40XY1234";
		Modelname="Royal Enfield classic 350";
		cost=200;
		CabDisplay();
	}

}

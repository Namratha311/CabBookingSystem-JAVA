package p;

public class sedan extends car{
	String SeatMaterial;
	String Sunroof;
	
	void Sedandisplay() {
		DriverName="Sam";
		Driverphno="9807698076";
		Numberplate="KA40XY7676";
		Modelname="Honda city";
		Sunroof="yes";
		SeatMaterial="Leather";
		cost=450;
		CabDisplay();
		System.out.println("SunRoof:"+Sunroof);
		System.out.println("Seat Material:"+SeatMaterial);

	}
	

}

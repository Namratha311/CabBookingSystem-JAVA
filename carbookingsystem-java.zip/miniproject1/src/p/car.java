package p;

public class car extends cab{
}

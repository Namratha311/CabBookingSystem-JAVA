package p;

public class cab {
	String DriverName;
	String Driverphno;
	String Numberplate;
	String Modelname;
	double cost;
	
	void CabDisplay() {
		System.out.println("YOUR RIDE IS BOOKED");
		System.out.println("Driver Name:"+DriverName);
		System.out.println("Driver PhoneNumber:"+Driverphno);
		System.out.println("Number Plate:"+Numberplate);
		System.out.println("Model Name:"+Modelname);
		System.out.println("Cost:"+cost );
	}	
}

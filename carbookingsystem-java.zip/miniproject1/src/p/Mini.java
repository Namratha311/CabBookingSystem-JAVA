package p;

public class Mini extends car {
		long bootspace;
		
		void MiniDisplay() {
			DriverName="John";
			Driverphno="9807698076";
			Numberplate="KA40XY7676";
			Modelname="Swift Mini";
			cost=250;
			bootspace=300L;
			CabDisplay();
			System.out.println("Boot space:"+bootspace);
		}
		
	}

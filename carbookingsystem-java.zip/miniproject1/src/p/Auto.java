package p;

public class Auto extends bike{

	
	void AutoDisplay() {
		DriverName="Ram";
		Driverphno="9807698076";
		Numberplate="KA40XY6789";
		Modelname="Bajaj Maxima Z";
		cost=90;
		CabDisplay();
	}

}

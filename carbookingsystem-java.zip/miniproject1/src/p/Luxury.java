package p;

public class Luxury extends car{
String Wifi;
String MassagerSeats;

void Luxurydisplay() {
	DriverName="Krish";
	Driverphno="9807695678";
	Numberplate="KA40XY7076";
	Modelname="BMW 7 Series";
	cost=2000;
	Wifi="Yes";
	MassagerSeats="Yes";
	CabDisplay();
	System.out.println("Wifi:"+Wifi);
	System.out.println("Massager Seat:"+MassagerSeats);
		
	}
}

